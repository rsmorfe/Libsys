<?php

header("location: library/index.php");

?>