<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['login'])==0) {
    header('location:userlogin.php');
} else {
    header('location:dashboard.php');
}

?>
