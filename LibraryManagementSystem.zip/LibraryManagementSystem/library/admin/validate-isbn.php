<?php 
require_once("includes/config.php");
// validate ISBN if already exists
if(!empty($_POST["isbn"])) {
	$isbn= $_POST["isbn"];
	
	$sql ="SELECT ISBNNumber FROM tblbooks WHERE ISBNNumber=:isbn";
	$query= $dbh -> prepare($sql);
	$query-> bindParam(':isbn', $isbn, PDO::PARAM_STR);
	$query-> execute();
	$results = $query -> fetchAll(PDO::FETCH_OBJ);
	$cnt=1;
	if($query -> rowCount() > 0)
	{
		echo "<span style='color:red'> ISBN already exists .</span>";
 		echo "<script>$('#submit').prop('disabled',true);</script>";

	} else {
		/*
		echo "<span style='color:green'> ISBN available for Registration .</span>";
		*/
	 	echo "<script>$('#submit').prop('disabled',false);</script>";
	 	
	}
}

?>