<?php

$sql = "SELECT id from tblauthors where AuthorName = :authorname";
$query = $dbh -> prepare($sql);
$query->bindParam(':authorname',$author,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchColumn();

?>