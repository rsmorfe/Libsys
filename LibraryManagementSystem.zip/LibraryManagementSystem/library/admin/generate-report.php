<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else{?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>SCSM Library Management System | Reports</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
<!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->


<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Generate Report</h4> 
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
            Available Reports:
            <select onchange="LoadOptions(this.value)">
                <option value="">Select Report</option>
                <option value="issued-books">Issued Books</option>
                <option value="returned-books">Returned Books</option>
                <option value="unreturned-books">Unreturned Books</option>
            </select>
            </div>
            <div class="panel-body" id="load-content">

            </div>
        </div>
    </div>
</div>

<!-- FOR LOADING REPORT OPTIONS -->
    <script type="text/javascript">
    function LoadOptions(val) {
    var optname = val;
    if (optname == "issued-books") {
    $(document).ready( function() {
            $("#load-content").load("rpt-issued.php");
        });
    } 

    if (optname == "returned-books") {
    $(document).ready( function() {
            $("#load-content").load("rpt-returned.php");
        });
    }

    if (optname == "unreturned-books") {
    $(document).ready( function() {
            $("#load-content").load("rpt-unreturned.php");
        });
    }
    }

    </script>

    <!-- CONTENT-WRAPPER SECTION END-->
<?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>

<?php } ?>