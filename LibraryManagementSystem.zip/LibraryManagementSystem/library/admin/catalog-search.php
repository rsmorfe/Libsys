<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}

?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>SCSM Library Management System | Catalog Search</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
<div class="container">
    <div class="row pad-botm">
        <div class="col-md-12">
            <h4 class="header-line">Catalog Search</h4>
            <!--
                </br>
                <button class="btn btn-primary"> Author</button>
                <button class="btn btn-primary"> Book</button> 
                <button class="btn btn-primary"> Issue Book</button>
            -->     
        </div>
    </div>
    <div class="row">
    <div class="col-md-12">
    <!-- Advanced Tables -->
    <div class="panel panel-default">
        <div class="panel-heading">
        Book Catalog
        <select id="categorylist" onchange="document.location ='catalog-search.php?category='+ document.getElementById('categorylist').value;">
                                <option value="">
                                    Select Category  
                                </option>
                              
<?php $sql = "SELECT CategoryName from tblcategory where Status = 1 order by CategoryName ASC";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>      
                                <option value="<?php echo htmlentities($result->CategoryName);?> ">
                                    <?php echo htmlentities($result->CategoryName);?>   
                                </option></a>
 <?php }} ?>   
                            </select> 
        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-hover" id="dataTables-example">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Location</th>
                        <th>Category</th>
                        <th>ISBN</th>
                        <th>Book Name</th>
                        <th>Author </th>
                        <th>Stock</th>
                        <th>Available</th>
                        <th>Issued</th>
                        <!--<th> </th>-->
                    </tr>
                    </thead>
                    <tbody>
<?php 
if (isset($_GET['category'])) { 
    $cat = $_GET['category'];
    $sql = "SELECT a.id as BookID,ShelfLocation as Location,ISBNNumber as ISBN,BookName,b.CategoryName as Category,c.AuthorName as Author,BookQty,(BookQty - (select count(BookId) from tblissuedbookdetails where BookId = a.id And RetrunStatus = 0))as Available,(select count(BookId) from tblissuedbookdetails where BookId = a.id And RetrunStatus = 0) as Issued,(select count(Bookid) from tblissuedbookdetails where BookId = a.id) as BorrowCount from tblbooks as a join tblcategory as b on b.id = a.catid join tblauthors as c on c.id = a.authorid where b.CategoryName=:cat order by BorrowCount desc";
    $query = $dbh -> prepare($sql);
    $query -> bindParam(':cat',$cat, PDO::PARAM_STR);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    $cnt=1;
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {               ?>                                      
            <tr class="odd gradeX">
            <td class="center"><?php echo htmlentities($cnt);?></td>
            <td class="center"><?php echo htmlentities($result->Location);?></td>
            <td class="center"><?php echo htmlentities($result->Category);?></td>
            <td class="center"><?php echo htmlentities($result->ISBN);?></td>
            <td class="center"><?php echo htmlentities($result->BookName);?></td>
            <td class="center"><?php echo htmlentities($result->Author);?></td>
            <td class="center"><?php echo htmlentities($result->BookQty);?></td>
            <td class="center"><?php echo htmlentities($result->Available);?></td>
            <td class="center"><?php echo htmlentities($result->Issued);?></td>
            <!--
            <td class="center">
                <a href="issue-book.php?bookid=<?php //echo htmlentities($result->BookID);?>"><button class="btn btn-primary btn-sm"><i class="fa fa-edit "></i> Issue Book</button>
            </td>
             -->
            </tr>
 <?php $cnt=$cnt+1;}}
} else {
    $sql = "SELECT a.id as BookID,ShelfLocation as Location,ISBNNumber as ISBN,BookName,b.CategoryName as Category,c.AuthorName as Author,BookQty,(BookQty - (select count(BookId) from tblissuedbookdetails where BookId = a.id And RetrunStatus = 0))as Available,(select count(BookId) from tblissuedbookdetails where BookId = a.id And RetrunStatus = 0) as Issued,(select count(Bookid) from tblissuedbookdetails where BookId = a.id) as BorrowCount from tblbooks as a join tblcategory as b on b.id = a.catid join tblauthors as c on c.id = a.authorid order by BorrowCount DESC";
    $query = $dbh -> prepare($sql);
    $query->execute();
    $results=$query->fetchAll(PDO::FETCH_OBJ);
    $cnt=1;
    if($query->rowCount() > 0)
    {
        foreach($results as $result)
        {               ?>                                      
            <tr class="odd gradeX">
            <td class="center"><?php echo htmlentities($cnt);?></td>
            <td class="center"><?php echo htmlentities($result->Location);?></td>
            <td class="center"><?php echo htmlentities($result->Category);?></td>
            <td class="center"><?php echo htmlentities($result->ISBN);?></td>
            <td class="center"><?php echo htmlentities($result->BookName);?></td>
            <td class="center"><?php echo htmlentities($result->Author);?></td>
            <td class="center"><?php echo htmlentities($result->BookQty);?></td>
            <td class="center"><?php echo htmlentities($result->Available);?></td>
            <td class="center"><?php echo htmlentities($result->Issued);?></td>
            <!--
            <td class="center">
                <a href="issue-book.php?bookid=<?php //echo htmlentities($result->BookID);?>"><button class="btn btn-primary btn-sm"><i class="fa fa-edit "></i> Issue Book</button>
            </td>
             -->
            </tr>
 <?php $cnt=$cnt+1;}}}?>                                      
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--End Advanced Tables -->


    </div>
    </div>
</div>
</div>
<!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>