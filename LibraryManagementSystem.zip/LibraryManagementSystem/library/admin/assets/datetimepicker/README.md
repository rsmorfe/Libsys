# Deprecation warning!
This repository has been deprecated in favour of [this](https://eonasdan.github.io/bootstrap-datetimepicker/).
