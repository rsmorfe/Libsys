<?php
include('../includes/config.php');
require('../fpdf/fpdf.php');
/*
[During Instantiation of FPDF]
A4 width : 219mm
default margin : 10mm each side
writable horizontal line : 219 - (10*2) = 189mm

[Using the Cell() function]
Cell(width, height, text, border, end line, [align])
border = (0:no border,1:bordered)
end line = (0:continue,1:new line),
align = (L:left align(default),C:Center,R;Right)

*/

$pdf = new FPDF('p','mm','A4'); // instantiate FPDF

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage(); // create page


$pdf->SetFont('Arial','B',14); // Header - School Name


$pdf->Image('../assets/img/logo2.jpg',10,10,30); // School Logo
$pdf->Ln();
$pdf->Cell(32);
$pdf->Cell(32);$pdf->Cell(32,5,'           ');
$pdf->Ln();
$pdf->Cell(32);
$pdf->Cell(130,5,'Sunshine Christian School of Muntinlupa',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - School Address 
$pdf->Cell(32);
$pdf->Cell(130,5,'Poblacion, Muntinlupa City',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - Contact No
$pdf->Cell(32);
$pdf->Cell(130,5,'Tel No: xxx-xxxx',0,0,'C');
$pdf->Ln();

// Add New Line
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();

// Title
$pdf->SetFont('Arial','B',12); // Header - Contact No
$pdf->Cell(189,5,'Unreturned Books',0,0,'C'); // max width
$pdf->Ln();
$pdf->Ln();

// Content
// Content-header
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25,5,'Student ID',1,0,''); 
$pdf->Cell(40,5,'Full Name',1,0,''); 
$pdf->Cell(25,5,'ISBN',1,0,''); 
$pdf->Cell(60,5,'Title',1,0,''); 
$pdf->Cell(40,5,'Date Issued',1,0,''); 
// Content-data
$pdf->SetFont('Arial','',9);
$pdf->Ln();
// Query
$sql = "SELECT tblstudents.StudentID as sid,tblstudents.FullName,tblbooks.BookName,tblbooks.ISBNNumber,tblissuedbookdetails.IssuesDate from  tblissuedbookdetails join tblstudents on tblstudents.StudentId=tblissuedbookdetails.StudentId join tblbooks on tblbooks.id=tblissuedbookdetails.BookId where tblissuedbookdetails.RetrunStatus = 0 order by tblissuedbookdetails.id asc";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

foreach ($results as $result) {
	// insert data to cell
	$pdf->Cell(25,5,$result->sid,0,0,''); 
	$pdf->Cell(40,5,$result->FullName,0,0,''); 
	$pdf->Cell(25,5,$result->ISBNNumber,0,0,''); 
	$pdf->Cell(60,5,$result->BookName,0,0,''); 
	$pdf->Cell(40,5,$result->IssuesDate,0,0,''); 
	$pdf->Ln();
}
$pdf->Output(); // generate pdf on browser
?>