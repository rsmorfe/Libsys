<?php
include('../includes/config.php');
require('../fpdf/fpdf.php');
/*
[During Instantiation of FPDF]
A4 width : 219mm
default margin : 10mm each side
writable horizontal line : 219 - (10*2) = 189mm

[Using the Cell() function]
Cell(width, height, text, border, end line, [align])
border = (0:no border,1:bordered)
end line = (0:continue,1:new line),
align = (L:left align(default),C:Center,R;Right)

*/

$pdf = new FPDF('p','mm','A4'); // instantiate FPDF

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage('L'); // create page


$pdf->SetFont('Arial','B',14); // Header - School Name
$pdf->SetLeftMargin(20);

$pdf->Image('../assets/img/logo2.jpg',65,10,30); // School Logo

$pdf->Ln();
$pdf->Cell(88);
$pdf->Cell(88);$pdf->Cell(88,5,'           ');
$pdf->Ln();
$pdf->Cell(85);
$pdf->Cell(88,5,'Sunshine Christian School of Muntinlupa',0,0,'C');
$pdf->Ln();


$pdf->SetFont('Arial','',11); // Header - School Address 
$pdf->Cell(83);
$pdf->Cell(83,5,'Poblacion, Muntinlupa City',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - Contact No
$pdf->Cell(83);
$pdf->Cell(83,5,'Tel No: xxx-xxxx',0,0,'C');
$pdf->Ln();

// Add New Line
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();

// Title
$pdf->SetFont('Arial','B',12); // Header - Contact No
$pdf->Cell(250,5,'Returned Books w/ Penalty',0,0,'C'); // max width
$pdf->Ln();
$pdf->Ln();

// Content
// Content-header
$pdf->SetFont('Arial','B',10);
$pdf->Cell(40,5,'Issued Date',1,0,''); 
$pdf->Cell(25,5,'Student ID',1,0,''); 
$pdf->Cell(55,5,'Full Name',1,0,''); 
$pdf->Cell(25,5,'ISBN',1,0,''); 
$pdf->Cell(75,5,'Book Name',1,0,''); 
$pdf->Cell(25,5,'Fine',1,0,''); 

// Content-data
$pdf->SetFont('Arial','',9);
$pdf->Ln();
// Query
$sql = "SELECT a.IssuesDate,a.StudentID,b.Fullname,c.ISBNNumber,c.BookName,a.fine from tblissuedbookdetails as a join tblstudents as b on b.StudentId = a.StudentID join tblbooks as c on c.id = a.Bookid where a.fine > 0 order by a.IssuesDate desc";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalfines = 0;
foreach ($results as $result) {
	// insert data to cell
	$totalfines = $totalfines + $result->fine;
	$pdf->Cell(40,5,$result->IssuesDate,0,0,''); 
	$pdf->Cell(25,5,$result->StudentID,0,0,''); 
	$pdf->Cell(55,5,$result->Fullname,0,0,''); 
	$pdf->Cell(25,5,$result->ISBNNumber,0,0,''); 
	$pdf->Cell(75,5,$result->BookName,0,0,''); 
	$pdf->Cell(25,5,bcadd($result->fine, '0',2),0,0,'R'); 
	$pdf->Ln();
}
	$pdf->Ln();
	$pdf->Cell(245,5,"_________________________",0,0,'R');
	$pdf->Ln();
	//$pdf->Line(220, 114, 264, 114);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell(220,5,'Total Fines: ',0,0,'R');
	$pdf->Cell(25,5,bcadd($totalfines,'0',2),0,0,'R');
$pdf->Output(); // generate pdf on browser
?>