<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {
    header('location:../adminlogin.php');
} else {
    header('location:dashboard.php');
}

?>
