<?php
session_start();
include('includes/config.php'); 
$userid = $_SESSION['stdid'];
if (isset($_SESSION['ForgotToLogOut'])) {
	// Record Session - START (IF FORGOT TO LOGGED OUT FROM THE PREVIOUS DAY/S)
	$sql1 = "update sessionlogs set Status = 2 where UserId = :userid and Status = 1";
	$query1= $dbh -> prepare($sql1);
	$query1-> bindParam(':userid', $userid, PDO::PARAM_STR);
	$query1-> execute();
	// Record Session - END
} else {
	// Log session - START
	$sql2 = "INSERT INTO loginhistory(UserType,UserId,LoginStatus,vercode) VALUES ('User',:userid,'Logged Out',:vercode)";
	$query2= $dbh -> prepare($sql2);
	$query2-> bindParam(':userid', $userid, PDO::PARAM_STR);
	$query2-> bindParam(':vercode', $_SESSION["currcode"], PDO::PARAM_STR);
	$query2-> execute();
	// Log session - END

	// Record Session - START
	$sql3 = "update sessionlogs set Status = 2 where SessionId = :sessionid";
	$query3= $dbh -> prepare($sql3);
	$query3-> bindParam(':sessionid', session_id(), PDO::PARAM_STR);
	$query3-> execute();
	// Record Session - END
}

$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 60*60,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
unset($_SESSION['login']);
session_destroy(); // destroy session
header("location:index.php");
exit(); 
?>

