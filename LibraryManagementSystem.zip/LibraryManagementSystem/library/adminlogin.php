<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('get-browser-name.php');
if($_SESSION['alogin']!=''){
$_SESSION['alogin']='';
}
if(isset($_POST['login']))
{
 //code for verification
if ($_POST["vercode"] != $_SESSION["vercode"] OR $_SESSION["vercode"]=='')  {
        echo "<script>alert('Incorrect verification code');</script>" ;
} else {

$username=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT id,UserName,Password FROM admin WHERE UserName=:username and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':username', $username, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];

foreach ($results as $result) {
    $_SESSION['adminId'] = $result->id;
}
$userid = $_SESSION['adminId'];
// Check Session - START
$sql1 = "SELECT Userid,BrowserName,SessionId,logdatetime,Status from sessionlogs where Userid = :userid and Status = 1";
$query1= $dbh -> prepare($sql1);
$query1-> bindParam(':userid', $userid, PDO::PARAM_STR);
$query1-> execute();

$sessiondata = $query1->fetchAll(PDO::FETCH_OBJ);
    if($query1->rowCount() > 0) {
        foreach ($sessiondata as $session) {
            $date1 = new DateTime ($session->logdate);
            $sess_browser = $session->BrowserName;
            $login_status = $session->Status;
        }
        $date2 = new DateTime (date("Y-m-d"));
        $difference = $date2->diff($date1);
        $days = $difference->format('%a'); // difference in days
        $hours = $difference->format('%H'); // difference in hours
        $minutes = $difference->format('%i'); // difference in minutes
        if($curr_browser != $sess_browser) {
            echo "<script>alert('You are currently logged in from another browser');</script>";
            unset($_SESSION['alogin']);
        } else {
            if ($login_status == 1 && $days > 0 || $hours > 0 || $minutes > 0) {
            // original : elseif (($days < 0) || ($hours < 0) || ($minutes <= -30))
                $_SESSION['ForgotToLogOut'] = 1;
                echo "<script type='text/javascript'>alert('System detected that you forgot to logged out. Proceeding to logging out your account..');window.location.href='http://localhost/LibraryManagementSystem/library/admin/logout.php';</script>";
            } 
        }

        
    } else {
         
    // Check Session - END

    // Login details - START
    $sql2 = "INSERT INTO loginhistory(UserType,UserId,LoginStatus,vercode) VALUES ('Admin',:userid,'Logged In',:vercode)";
    $query2= $dbh -> prepare($sql2);
    $query2-> bindParam(':userid', $userid, PDO::PARAM_STR);
    $query2-> bindParam(':vercode', $_SESSION["vercode"], PDO::PARAM_STR);
    $query2-> execute();
    $_SESSION["currcode"] = $_SESSION["vercode"];
    // Login details - END

    // Record Session - START
    $sql3 = "INSERT INTO sessionlogs(UserType,UserId,BrowserName,SessionId,Status) VALUES ('Admin',:userid,:browser,:sessionid,'1')";
    $query3= $dbh -> prepare($sql3);
    $query3-> bindParam(':userid', $userid, PDO::PARAM_STR);
    $query3-> bindParam(':browser', $curr_browser, PDO::PARAM_STR);
    $query3-> bindParam(':sessionid', session_id(), PDO::PARAM_STR);
    $query3-> execute();
    // Record Session - END
    echo "<script type='text/javascript'> document.location ='admin/dashboard.php'; </script>"; 
    }
    } else {
    echo "<script>alert('Invalid Details');</script>";
    }}
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>SCSM Library Management System</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
<div class="container">
<div class="row pad-botm">
<div class="col-md-12">
<h4 class="header-line">ADMIN LOGIN FORM</h4>
</div>
</div>
             
<!--LOGIN PANEL START-->           
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
<div class="panel panel-info">
<div class="panel-heading">
 LOGIN FORM
</div>
<div class="panel-body">
<form role="form" method="post">

<div class="form-group">
<label>Enter Username</label>
<input class="form-control" type="text" name="username" autocomplete="off" required />
</div>
<div class="form-group">
<label>Password</label>
<input class="form-control" type="password" name="password" autocomplete="off" required />
</div>
 <div class="form-group">
<label>Verification code : </label>
<input type="text"  name="vercode" maxlength="5" autocomplete="off" required style="width: 150px; height: 25px;" />&nbsp;<img src="captcha.php">
</div>  

 <button type="submit" name="login" class="btn btn-info">LOGIN </button>
</form>
 </div>
</div>
</div>
</div>  
<!---LOGIN PABNEL END-->            
             
 
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
 <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</script>
</body>
</html>
