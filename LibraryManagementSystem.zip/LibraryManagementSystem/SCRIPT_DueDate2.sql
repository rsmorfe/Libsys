SELECT tblstudents.FullName,tblbooks.BookName,tblbooks.ISBNNumber,tblissuedbookdetails.IssuesDate,
tblissuedbookdetails.ReturnDate,(CASE WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=2) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 5 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=3) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 4 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=4) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 3 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=1) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 3 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=0) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 3 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=5) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 2 DAY)),' 23:59:59') 
WHEN (WEEKDAY(tblissuedbookdetails.IssuesDate)=6) 
THEN CONCAT(DATE(DATE_ADD(tblissuedbookdetails.IssuesDate,INTERVAL 1 DAY)),' 23:59:59') END) AS DueDate,
tblissuedbookdetails.id as rid from tblissuedbookdetails join tblstudents 
on tblstudents.StudentId=tblissuedbookdetails.StudentId join tblbooks 
on tblbooks.id=tblissuedbookdetails.BookId where (CASE WHEN (WEEKDAY(IssuesDate)=2) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 5 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=3) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 4 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=4) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 3 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=1) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 3 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=0) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 3 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=5) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 2 DAY)),' 23:59:59') WHEN (WEEKDAY(IssuesDate)=6) 
THEN CONCAT(DATE(DATE_ADD(IssuesDate,INTERVAL 1 DAY)),' 23:59:59') END) > DATE(DATE_ADD(NOW(),INTERVAL 1 DAY)) 
order by tblissuedbookdetails.id desc